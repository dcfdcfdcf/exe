	function vue(el,json){
		//console.log(typeof(el))
		if(typeof(el) == "string"){
			this.el = document.getElementById(el);
		}else if(typeof(el) == "Object"){
			this.el = el;
		}
		
		this.json = json;
		this.add();

		if(this.el.tagName == "INPUT"){
			var _this = this;	
			this.el.onkeyup = function(){
				
				_this.json[this.getAttribute("ng")] = this.value;
				
			}
		}
	}
	vue.prototype.add = function(){
		
		for(var attr in this.json){
			if(attr == this.el.getAttribute("ng")){
				//console.log(this.el.tagName)
				if(this.el.tagName == "INPUT"){
					this.el.value = this.json[attr];

				}else{
					this.el.innerHTML = this.json[attr];
				}
			}
		};

	};
