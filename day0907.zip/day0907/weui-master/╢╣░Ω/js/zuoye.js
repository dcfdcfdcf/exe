// ni  ni  ni n ni ni n i ni 
window.onload = function(){
    ////////////////////////
  ///第一页滚动条////////
  ///////////////////////
  var deviceWidth = document.documentElement.clientWidth;
  if(deviceWidth > 720){
      deviceWidth = 720;
  };
  document.documentElement.style.fontSize = deviceWidth / 2.95 + 'px';
   ////////////////////////
  ///第一页banner////////
  ///////////////////////
  var swiper = new Swiper('.swiper-container', {
      pagination: '.swiper-pagination',
      paginationClickable: true,
      loop:true,
      autoplay:2000,
  });
  ////////////////////////
  ///第一页滚动条////////
  ///////////////////////

  
}

