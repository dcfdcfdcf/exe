﻿// JavaScript Document
//使用：var tool = new tool();
//tool.move()
function Tool(){};

Tool.prototype.getStyle = function(obj,attr )
{
	return obj.currentStyle ? obj.currentStyle[attr] : getComputedStyle(obj)[attr];
};


Tool.prototype.css = function( obj,attr,value )
{
	if( arguments.length == 2 )
	{
		
		return obj.style[attr];
	}
	else if( arguments.length == 3 )
	{
		//console.log(333);
		obj.style[attr] = value;
	};
	
};

Tool.prototype.toZero = function( n )
{
	return n < 10 ? '0'+n : ''+n;
};

Tool.prototype.getId = function ( s )
{
	return document.getElementById( s );
};

Tool.prototype.v = function( s )
{
	if( typeof s == 'function' )
	{
		window.onload = s;
	}
	else if( typeof s == 'string' ){
		return document.getElementById( s );		
	}
	else if( typeof s == 'object' )
	{
		return s;
	};
};
Tool.prototype.createSn = function()
{
	var oTime = new Date();
	
	var iYear = oTime.getFullYear();
	var iMonth = this.toZero(oTime.getMonth()+1);
	var iDay = this.toZero(oTime.getDate());
	var iHour = this.toZero(oTime.getHours());
	var iMin = this.toZero(oTime.getMinutes());
	var iSec = this.toZero(oTime.getSeconds());
	
	var nRan = Math.random().toString().substring(2,6);
	
	var iTime = oTime.getTime().toString().substring(0,13);
	
	//console.log( nRan );
	
	//console.log( oTime.getTime() );//时间戳 从1970
	
	var str = '';
	str = iYear + iMonth + iDay + nRan + iTime;
	
	return str;
};

//var timer = null;
//匀速运动框架
Tool.prototype.move = function( obj,attr,target,endFn )
{
	var _this = this;
	clearInterval( obj.timer );//clearInterval 脾气特别好。可以清除任意数据类型
	obj.timer = setInterval( function(){
		var dir = parseInt(_this.getStyle( obj,attr )) < target ? 10 : -10;//判断方向
		var speed = parseInt(_this.getStyle( obj,attr )) + dir;
		
		if( speed >= target && dir > 0 || speed <= target && dir < 0 )//500
		{
			speed = target;
			clearInterval( obj.timer );
			endFn && endFn();
			
		};
		
		obj.style[attr] = speed + 'px';
		
		
	},30 );
	
};

//检测是否为一个数字
Tool.prototype.isNum = function( s )
{
	var num = 0;
	for( var i=0;i<s.length;i++ )
	{
		num++;
		if( !( s.charCodeAt(i) >= 48 && s.charCodeAt(i) <= 57 ) )
		{
			console.log(num);
			return false;
		};
	};
	
	return true;
	
};

//元素位置
Tool.prototype.getPosition = function( obj )
{
	var position = { "L":0,"T":0 };

	//var obj = oDiv2;
	
	while( obj )
	{
		position.L += obj.offsetLeft;
		position.T += obj.offsetTop;
		
		obj = obj.offsetParent;
	};
	
	return position;
};


//通过className找元素
Tool.prototype.byClassName = function( oParent,sClassName )
{
	
	var arrEle = [];
	
	var aEle = oParent.getElementsByTagName('*');
	
	//console.log( aEle );
	
	for(var i=0;i<aEle.length;i++)
	{
		
		var arrClassName = aEle[i].className.split(' ');
		
		//console.log( arrClassName );
		
		for(var j=0;j<arrClassName.length;j++)
		{
			if( arrClassName[j] == sClassName )
			{
				arrEle.push( aEle[i] );
				break;
			};
		};
		
	};
	
	return arrEle;
	
};


//缓冲运动 
Tool.prototype.sMove = function(obj,json,endFn)
{
	var _this = this;
	clearInterval( obj.timer );
	
	obj.timer = setInterval(function(){
		
		//for in循环如果里面不加清定时器的功能，那么所有的属性都可以到达目标位置。
		/*
			
			理解为：for in循环里面就是 为了让元素到达目标位置的； 每次执行for in循环 就是让当前位置的cur + speed 累加的。
			
			判断所有的属性到达到目标位置与否。如果所有属性都到达目标位置，则清除定时器
			
		*/
		
		var isStop = true;//假如都到达目标位置了，则为true，只要有一个属性未到达目标位置，则为false
		
		for( var attr in json )
		{
			if( attr == 'opacity')
			{
				var cur = Math.round(parseFloat(_this.getStyle( obj,attr ))*100);//
				//console.log('2:' + cur)	
			}
/*			else if(attr == 'zIndex')
			{
				
				var cur = Math.round(parseFloat(_this.getStyle( obj,'zIndex' ))*100);//
				console.log('1:' + cur)	
			}
*/			else
			{
				var cur = parseInt( _this.getStyle( obj,attr ) );//
			};
			
			
			var speed = (json[attr] - cur)/10;
			speed = speed > 0 ? Math.ceil( speed ) : Math.floor( speed );

			cur += speed;//100 = 100 +
			
			if( cur != json[attr] )
			{
				isStop = false;
			};
			
			if( attr == 'opacity' )
			{
				obj.style.opacity = cur/100;
				obj.style.filter = 'alpha(opacity='+ cur +')';
			}
			else if(attr == 'zIndex')
			{
				obj.style.zIndex = cur;	
			}
			else
			{
				obj.style[attr] = cur + 'px';
			};
		};
		
		
		if( isStop )
		{ 
			clearInterval( obj.timer );
			endFn && endFn();
		};
	
		
	},30);
	
};
//设置cookie
Tool.prototype.setCookie = function( name,value,iDay )
{
	var iTime = new Date();
	
	iTime.setDate( iTime.getDate() + iDay );
	
	document.cookie = name + '='+ value +';expires=' + iTime ;
};
//获取cookie
Tool.prototype.getCookie = function ( name )
{
	var sValue = document.cookie.split('; ');
	for( var i=0;i<sValue.length;i++ )
	{
		var arrNew = sValue[i].split( '=' );
		if( name == arrNew[0] )
		{
			return arrNew[1];
		};
	};
	return '';
};
//删除cookie
Tool.prototype.removeCookie = function ( name )
{
	setCookie( name,'1324fdsaf',-2 );
};
//url 向服务器端请求文件 
//http://localhost/a.txt
//fnSucc  成功以后，执行成功的函数
//fnFaild 请求失败以后，执行失败的函数
Tool.prototype.ajax = function (url, fnSucc, fnFaild)
{
	//1.创建Ajax对象
	if(window.XMLHttpRequest)
	{
		var oAjax=new XMLHttpRequest();
	}
	else
	{
		var oAjax=new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	//2.连接服务器（打开和服务器的连接）
	oAjax.open('GET', url, true);
	
	
	//3.发送
	oAjax.send();
	
	//4.接收
	oAjax.onreadystatechange=function ()
	{
		if(oAjax.readyState==4)
		{
			if(oAjax.status==200)
			{
				//alert('成功了：'+oAjax.responseText);
				fnSucc(oAjax.responseText);
			}
			else
			{
				//alert('失败了');
				if(fnFaild)
				{
					fnFaild();
				}
			}
		}
	};
}

	
