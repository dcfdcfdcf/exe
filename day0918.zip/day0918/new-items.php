<?php 
	$str = '';
	$conn = new sqli("localhost","root","root","item1");
	if($conn->connect_error){
		die("失败");
	};
	$sql = "SELECT * FROM admin_article LIMIT 0 8";
	$result = $conn->query($sql);
	if($result->num_rows>0){
		while($rows=$result->fetch_assoc()){
			if(empty($str)){
 				$str .= $rows[articel_col];
			}else{
				$str .= ",".$rows[articel_col];
			}
			
		}
	}
	echo "[".$str."]"
?>